import gradio as gr
import numpy as np
import pandas as pd
import pickle
import json
import os

# Load the trained model and feature information
def load_model_and_info():
    try:
        with open('best_model.pkl', 'rb') as f:
            model = pickle.load(f)
        
        with open('feature_info.json', 'r') as f:
            feature_info = json.load(f)
        
        return model, feature_info
    except Exception as e:
        print(f"Error loading model: {e}")
        return None, None

# Load model and feature info
model, feature_info = load_model_and_info()

# Get feature names
feature_names = feature_info['feature_names'] if feature_info else []

def predict_house_price(bedrooms, bathrooms, toilets, parking_space, title_Duplex, title_Flat, title_House, title_Terraced_Bungalow, 
                       town_Abule_Egba, town_Agege, town_Ajah, town_Alagbado, town_Alimosho, town_Ibeju_Lekki, 
                       town_Ifako_Ijaiye, town_Ikeja, town_Ikorodu, town_Ikoyi, town_Isolo, town_Kosofe, 
                       town_Lekki, town_Magodo, town_Maryland, town_Mushin, town_Ojodu, town_Others, 
                       town_Shomolu, town_Surulere, town_Victoria_Island, town_Yaba):
    try:
        if model is None:
            return "❌ Model not loaded. Please check the model file."
        
        # Create input data dictionary
        input_data = {
            'bedrooms': bedrooms,
            'bathrooms': bathrooms,
            'toilets': toilets,
            'parking_space': parking_space,
            'title_Duplex': title_Duplex,
            'title_Flat': title_Flat,
            'title_House': title_House,
            'title_Terraced Bungalow': title_Terraced_Bungalow,
            'town_Abule Egba': town_Abule_Egba,
            'town_Agege': town_Agege,
            'town_Ajah': town_Ajah,
            'town_Alagbado': town_Alagbado,
            'town_Alimosho': town_Alimosho,
            'town_Ibeju Lekki': town_Ibeju_Lekki,
            'town_Ifako-Ijaiye': town_Ifako_Ijaiye,
            'town_Ikeja': town_Ikeja,
            'town_Ikorodu': town_Ikorodu,
            'town_Ikoyi': town_Ikoyi,
            'town_Isolo': town_Isolo,
            'town_Kosofe': town_Kosofe,
            'town_Lekki': town_Lekki,
            'town_Magodo': town_Magodo,
            'town_Maryland': town_Maryland,
            'town_Mushin': town_Mushin,
            'town_Ojodu': town_Ojodu,
            'town_Others': town_Others,
            'town_Shomolu': town_Shomolu,
            'town_Surulere': town_Surulere,
            'town_Victoria Island': town_Victoria_Island,
            'town_Yaba': town_Yaba
        }
        
        # Convert to DataFrame
        input_df = pd.DataFrame([input_data])
        
        # Ensure all features are in the correct order
        input_df = input_df.reindex(columns=feature_names, fill_value=0)
        
        # Make prediction
        prediction = model.predict(input_df)
        
        # Get model info
        model_type = feature_info['model_type'] if feature_info else 'Unknown'
        r2_score = feature_info['performance_metrics']['r2_score'] if feature_info else 0
        
        return f"💰 Predicted House Price: ₦{prediction[0]:,.2f}\n\n📊 Model: {model_type}\n🎯 R² Score: {r2_score:.4f}"
    
    except Exception as e:
        return f"❌ Error making prediction: {str(e)}"

# Create Gradio interface
def create_interface():
    with gr.Blocks(title="🏠 Lagos House Price Predictor", theme=gr.themes.Soft()) as demo:
        gr.Markdown("# 🏠 Lagos House Price Predictor")
        gr.Markdown("### Predict house prices in Lagos, Nigeria using machine learning")
        gr.Markdown("---")
        
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("## 🏡 Property Details")
                bedrooms = gr.Slider(minimum=1, maximum=10, value=3, step=1, label="Number of Bedrooms")
                bathrooms = gr.Slider(minimum=1, maximum=10, value=2, step=1, label="Number of Bathrooms")
                toilets = gr.Slider(minimum=1, maximum=10, value=3, step=1, label="Number of Toilets")
                parking_space = gr.Slider(minimum=0, maximum=10, value=2, step=1, label="Parking Spaces")
                
                gr.Markdown("## 🏘️ Property Type")
                title_Duplex = gr.Checkbox(label="Duplex", value=False)
                title_Flat = gr.Checkbox(label="Flat", value=False)
                title_House = gr.Checkbox(label="House", value=True)
                title_Terraced_Bungalow = gr.Checkbox(label="Terraced Bungalow", value=False)
            
            with gr.Column(scale=1):
                gr.Markdown("## 📍 Location (Select One)")
                town_Abule_Egba = gr.Checkbox(label="Abule Egba", value=False)
                town_Agege = gr.Checkbox(label="Agege", value=False)
                town_Ajah = gr.Checkbox(label="Ajah", value=False)
                town_Alagbado = gr.Checkbox(label="Alagbado", value=False)
                town_Alimosho = gr.Checkbox(label="Alimosho", value=False)
                town_Ibeju_Lekki = gr.Checkbox(label="Ibeju Lekki", value=False)
                town_Ifako_Ijaiye = gr.Checkbox(label="Ifako-Ijaiye", value=False)
                town_Ikeja = gr.Checkbox(label="Ikeja", value=True)
                town_Ikorodu = gr.Checkbox(label="Ikorodu", value=False)
                town_Ikoyi = gr.Checkbox(label="Ikoyi", value=False)
                town_Isolo = gr.Checkbox(label="Isolo", value=False)
                town_Kosofe = gr.Checkbox(label="Kosofe", value=False)
                town_Lekki = gr.Checkbox(label="Lekki", value=False)
                town_Magodo = gr.Checkbox(label="Magodo", value=False)
                town_Maryland = gr.Checkbox(label="Maryland", value=False)
                town_Mushin = gr.Checkbox(label="Mushin", value=False)
                town_Ojodu = gr.Checkbox(label="Ojodu", value=False)
                town_Others = gr.Checkbox(label="Others", value=False)
                town_Shomolu = gr.Checkbox(label="Shomolu", value=False)
                town_Surulere = gr.Checkbox(label="Surulere", value=False)
                town_Victoria_Island = gr.Checkbox(label="Victoria Island", value=False)
                town_Yaba = gr.Checkbox(label="Yaba", value=False)
        
        gr.Markdown("---")
        
        # Prediction button and output
        predict_btn = gr.Button("🔮 Predict House Price", variant="primary", size="lg")
        output = gr.Textbox(label="Prediction Result", lines=4, interactive=False)
        
        # Connect the prediction function
        predict_btn.click(
            predict_house_price,
            inputs=[
                bedrooms, bathrooms, toilets, parking_space,
                title_Duplex, title_Flat, title_House, title_Terraced_Bungalow,
                town_Abule_Egba, town_Agege, town_Ajah, town_Alagbado, town_Alimosho,
                town_Ibeju_Lekki, town_Ifako_Ijaiye, town_Ikeja, town_Ikorodu, town_Ikoyi,
                town_Isolo, town_Kosofe, town_Lekki, town_Magodo, town_Maryland,
                town_Mushin, town_Ojodu, town_Others, town_Shomolu, town_Surulere,
                town_Victoria_Island, town_Yaba
            ],
            outputs=output
        )
        
        # Add model information
        gr.Markdown("---")
        gr.Markdown("### 📊 Model Information")
        if feature_info:
            gr.Markdown(f"- **Model Type**: {feature_info['model_type']}")
            gr.Markdown(f"- **R² Score**: {feature_info['performance_metrics']['r2_score']:.4f}")
            gr.Markdown(f"- **RMSE**: ₦{feature_info['performance_metrics']['rmse']:,.2f}")
            gr.Markdown(f"- **MAE**: ₦{feature_info['performance_metrics']['mae']:,.2f}")
        
        gr.Markdown("---")
        gr.Markdown("*This model is trained on Lagos house price data and provides estimates based on historical patterns.*")
        gr.Markdown("*⚠️ Disclaimer: Predictions are estimates and should not be used as the sole basis for financial decisions.*")
    
    return demo

# Launch the app
if __name__ == "__main__":
    demo = create_interface()
    demo.launch()
