---
title: Lagos House Price Predictor
emoji: 🏠
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
license: mit
---

# 🏠 Lagos House Price Predictor

## Overview
This application predicts house prices in Lagos, Nigeria using machine learning. It's trained on real estate data from various locations across Lagos State.

## Features
- **Property Details**: Bedrooms, bathrooms, toilets, parking spaces
- **Property Types**: House, Flat, Duplex, Terraced Bungalow
- **Locations**: 22 different areas in Lagos including Lekki, Ikoyi, Victoria Island, Ikeja, and more

## Model Performance
- **Algorithm**: Random Forest Regressor (Best performing model)
- **R² Score**: ~0.85 (85% variance explained)
- **RMSE**: ~₦25M (Root Mean Square Error)
- **MAE**: ~₦15M (Mean Absolute Error)

## How to Use
1. Select property details (bedrooms, bathrooms, toilets, parking)
2. Choose property type (House, Flat, Duplex, or Terraced Bungalow)
3. Select location in Lagos
4. Click "Predict House Price" to get the estimated price

## Dataset
The model is trained on Lagos house price data with the following features:
- Property specifications (bedrooms, bathrooms, toilets, parking)
- Property types (encoded as binary features)
- Location information (22 different areas in Lagos)

## Disclaimer
This model provides price estimates based on historical data and should not be used as the sole basis for financial decisions. Always consult with real estate professionals for accurate valuations.

## Technical Details
- **Framework**: Gradio for web interface
- **ML Library**: Scikit-learn and XGBoost
- **Data Processing**: Pandas and NumPy
- **Model**: Ensemble of Random Forest, XGBoost, and Linear Regression (Random Forest selected as best)

## Contact
For questions or feedback about this model, please reach out through the discussion tab.
